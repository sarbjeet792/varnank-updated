import React from 'react';
import { ArrowRight, Bell, Contact, FileText, Image as ImageIcon, Printer } from 'lucide-react';
import { INITIAL_PLANS, StudioId } from '../core/engine';

export interface HomeStudio {
  id: StudioId;
  codeLabel: string;
  name: string;
  summary: string;
}

const STUDIO_ICONS: Record<StudioId, React.ComponentType<{ className?: string }>> = {
  S1: ImageIcon,
  S2: FileText,
  S3: Contact,
  S4: Printer,
};

interface StudioGridProps {
  studios: HomeStudio[];
  onLaunchStudio: (id: StudioId) => void;
}

/** Four studio cards. Each one opens that studio directly. Shared by guest Home and the signed-in dashboard. */
export const StudioGrid: React.FC<StudioGridProps> = ({ studios, onLaunchStudio }) => (
  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4" data-testid="home-studio-grid">
    {studios.map((studio) => {
      const Icon = STUDIO_ICONS[studio.id] || ImageIcon;
      return (
        <li key={studio.id}>
          <button
            type="button"
            data-testid={`home-open-studio-${studio.id}`}
            onClick={() => onLaunchStudio(studio.id)}
            className="group h-full w-full text-left p-5 rounded-xl bg-white dark:bg-[#1C1A18] border border-[#E7E2DA] dark:border-[#2E2B28] hover:border-[#B44C32] dark:hover:border-[#E06D53] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32] flex flex-col gap-3"
          >
            <span className="flex items-center gap-3">
              <span className="w-10 h-10 rounded-lg bg-[#FAF8F5] dark:bg-[#262320] border border-[#E7E2DA] dark:border-[#2E2B28] flex items-center justify-center text-[#B44C32] dark:text-[#E06D53] shrink-0">
                <Icon className="w-5 h-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-bold text-[#181615] dark:text-[#F5F2EB]">
                  {studio.name}
                </span>
                <span className="block text-xs text-[#57534E] dark:text-[#A8A29E]">
                  {studio.codeLabel}
                </span>
              </span>
            </span>
            <span className="text-sm text-[#57534E] dark:text-[#A8A29E] leading-relaxed">
              {studio.summary}
            </span>
            <span className="mt-auto pt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-[#B44C32] dark:text-[#E06D53]">
              Open studio
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 motion-reduce:transition-none" />
            </span>
          </button>
        </li>
      );
    })}
  </ul>
);

/** A passport-photo print sheet with crop marks: the thing the ID studio actually makes. */
const SheetIllustration: React.FC = () => {
  const frames = [
    { x: 38, y: 38 },
    { x: 132, y: 38 },
    { x: 38, y: 154 },
    { x: 132, y: 154 },
  ];
  const marks: Array<[number, number, number, number]> = [
    // top-left
    [18, 30, 30, 30], [30, 18, 30, 30],
    // top-right
    [210, 30, 222, 30], [210, 18, 210, 30],
    // bottom-left
    [18, 270, 30, 270], [30, 270, 30, 282],
    // bottom-right
    [210, 270, 222, 270], [210, 270, 210, 282],
  ];
  return (
    <svg
      viewBox="0 0 240 300"
      role="img"
      aria-label="A print sheet with four passport photos and crop marks"
      className="w-full max-w-[280px] h-auto"
    >
      <rect x="14" y="14" width="212" height="272" rx="6" className="fill-white dark:fill-[#1C1A18] stroke-[#E7E2DA] dark:stroke-[#2E2B28]" strokeWidth="1.5" />
      {frames.map((f, i) => (
        <g key={i}>
          <rect x={f.x} y={f.y} width="72" height="92" rx="2" className="fill-[#EAF1F7] dark:fill-[#2A3440] stroke-[#181615] dark:stroke-[#F5F2EB]" strokeWidth="1" />
          <circle cx={f.x + 36} cy={f.y + 38} r="14" className="fill-[#B44C32] dark:fill-[#E06D53]" opacity="0.9" />
          <path d={`M${f.x + 10} ${f.y + 92} C${f.x + 10} ${f.y + 66} ${f.x + 62} ${f.y + 66} ${f.x + 62} ${f.y + 92} Z`} className="fill-[#181615] dark:fill-[#F5F2EB]" opacity="0.85" />
        </g>
      ))}
      {marks.map(([x1, y1, x2, y2], i) => (
        <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} className="stroke-[#181615] dark:stroke-[#F5F2EB]" strokeWidth="1" />
      ))}
      <text x="120" y="146" textAnchor="middle" className="fill-[#57534E] dark:fill-[#A8A29E]" fontSize="9" fontFamily="var(--font-mono)">
        35 × 45 mm
      </text>
    </svg>
  );
};

interface HomeViewProps {
  studios: HomeStudio[];
  plans: Array<{ id: string; dailyExportLimit?: number }>;
  notices: Array<{ id: string; title: string; body: string }>;
  onLaunchStudio: (id?: StudioId) => void;
  onOpenPlans: () => void;
  onSignIn: () => void;
}

/** Start screen for people who are not signed in. */
export const HomeView: React.FC<HomeViewProps> = ({
  studios,
  plans,
  notices,
  onLaunchStudio,
  onOpenPlans,
  onSignIn,
}) => {
  const freePlan = plans.find((p) => p.id === 'FREE') || INITIAL_PLANS.FREE;
  const freeLimit = freePlan.dailyExportLimit ?? INITIAL_PLANS.FREE.dailyExportLimit;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-10 sm:py-14 pb-24 space-y-14" data-testid="home-view">
      {notices.length > 0 && (
        <div className="p-4 rounded-xl bg-white dark:bg-[#1C1A18] border border-[#E7E2DA] dark:border-[#2E2B28] space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#B44C32] dark:text-[#E06D53]">
            <Bell className="w-3.5 h-3.5" />
            <span>Platform notice</span>
          </div>
          {notices.map((n) => (
            <p key={n.id} className="text-xs">
              <span className="font-semibold">{n.title}: </span>
              <span className="text-[#57534E] dark:text-[#A8A29E]">{n.body}</span>
            </p>
          ))}
        </div>
      )}

      <section className="grid grid-cols-1 md:grid-cols-[1.25fr_1fr] gap-10 items-center">
        <div className="space-y-6">
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight leading-[1.1] text-[#181615] dark:text-[#F5F2EB]">
            Photos, PDFs and ID sheets, finished in your browser.
          </h1>
          <p className="text-base text-[#57534E] dark:text-[#A8A29E] leading-relaxed max-w-[52ch]">
            Crop, convert, merge, redact and lay out print-ready sheets. Your files are processed
            on this device and never uploaded.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              data-testid="home-open-studios-btn"
              onClick={() => onLaunchStudio()}
              className="min-h-[46px] px-5 py-2.5 text-sm font-semibold text-[#FAF8F5] bg-[#B44C32] hover:bg-[#9E3F27] rounded-xl transition-colors inline-flex items-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32]"
            >
              Start editing
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              data-testid="home-signin-btn"
              onClick={onSignIn}
              className="min-h-[46px] px-5 py-2.5 text-sm font-semibold text-[#181615] dark:text-[#F5F2EB] border border-[#181615] dark:border-[#F5F2EB] rounded-xl hover:bg-[#181615] hover:text-[#FAF8F5] dark:hover:bg-[#F5F2EB] dark:hover:text-[#121110] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32]"
            >
              Sign in or create account
            </button>
          </div>
          <p className="text-xs text-[#57534E] dark:text-[#A8A29E]">
            No account needed to start. Without a paid plan you get {freeLimit} exports a day.
          </p>
        </div>

        <div className="flex justify-center md:justify-end">
          <SheetIllustration />
        </div>
      </section>

      <section aria-labelledby="home-studios-heading" className="space-y-5">
        <h2 id="home-studios-heading" className="text-xl font-bold">
          Choose a studio
        </h2>
        <StudioGrid studios={studios} onLaunchStudio={(id) => onLaunchStudio(id)} />
      </section>

      <section
        aria-labelledby="home-account-heading"
        className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-[#1C1A18] border border-[#E7E2DA] dark:border-[#2E2B28] grid grid-cols-1 md:grid-cols-[1fr_auto] gap-6 items-center"
      >
        <div className="space-y-2">
          <h2 id="home-account-heading" className="text-lg font-bold">
            What an account adds
          </h2>
          <p className="text-sm text-[#57534E] dark:text-[#A8A29E] leading-relaxed max-w-[60ch]">
            Saved language, theme and export defaults, plan and billing in your own currency, and
            recovery codes in case you lose your device. Paid plans raise export quality and unlock
            batch runs and larger ID sheets.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={onOpenPlans}
            className="min-h-[44px] px-4 py-2 text-sm font-semibold border border-[#E7E2DA] dark:border-[#2E2B28] rounded-xl hover:border-[#B44C32] transition-colors focus-visible:outline-2 focus-visible:outline-[#B44C32]"
          >
            Compare plans
          </button>
        </div>
      </section>
    </div>
  );
};
