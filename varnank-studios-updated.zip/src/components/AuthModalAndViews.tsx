import React, { useEffect, useId, useRef, useState } from 'react';
import {
  AdminCategory,
  CountryCurrencyEntry,
  resolveCurrencyFromCountryCode,
} from '../core/engine';
import {
  ArrowRight,
  Check,
  ChevronDown,
  Copy,
  Download,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  LifeBuoy,
  Mail,
  ShieldCheck,
  X,
} from 'lucide-react';

interface EnabledSignInMethods {
  passkey: boolean;
  emailOtp: boolean;
  googleOAuth: boolean;
  password: boolean;
  appleOAuth: boolean;
  smsOtp: boolean;
  xOAuth: boolean;
}

export interface UnifiedAuthSuccessPayload {
  sessionToken: string;
  adminSessionToken?: string;
  roleCategory?: AdminCategory;
  entitlementToken: string;
  user: Record<string, unknown>;
  entitlement: Record<string, unknown>;
  oneTimeRecoveryKit?: string[];
  openAdminConsoleDirectly?: boolean;
}

interface AuthViewProps {
  countryCodes: CountryCurrencyEntry[];
  enabledMethods: EnabledSignInMethods;
  onAuthenticated: (payload: UnifiedAuthSuccessPayload) => void;
  isModal?: boolean;
  onClose?: () => void;
}

type AuthStep = 'IDENTIFY' | 'COMPLETE_SIGNUP' | 'RECOVERY';

const FIELD_CLASS =
  'w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl bg-[#FAF8F5] dark:bg-[#262320] border border-[#E7E2DA] dark:border-[#2E2B28] placeholder:text-[#8A847D] focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[#B44C32]';

const PRIMARY_BTN_CLASS =
  'w-full min-h-[46px] px-4 py-2.5 text-sm font-semibold text-[#FAF8F5] bg-[#B44C32] hover:bg-[#9E3F27] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#B44C32] rounded-xl transition-colors flex items-center justify-center gap-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32]';

const SECONDARY_BTN_CLASS =
  'min-h-[46px] px-4 py-2 text-sm font-medium border border-[#E7E2DA] dark:border-[#2E2B28] rounded-xl hover:border-[#B44C32] transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32]';

const LINK_BTN_CLASS =
  'font-semibold text-[#B44C32] dark:text-[#E06D53] hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32] rounded-sm';

const BrandMark: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg aria-hidden="true" viewBox="0 0 64 64" className={`${className} shrink-0 rounded-md`} fill="none">
    <rect width="64" height="64" rx="14" fill="#181615" />
    <path d="M14 18L26 46L38 18" stroke="#FAF8F5" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
    <path
      d="M36 42C38.5 44.8 42 46 45.5 46C50 46 53 43.2 53 39.5C53 35.8 49.8 34 44.5 32.5C39.5 31 36.5 28.8 36.5 24.5C36.5 20.5 39.8 18 44.8 18C48.2 18 51 19.2 52.8 21.2"
      stroke="#E06D53"
      strokeWidth="4.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const Spinner: React.FC = () => (
  <Loader2 aria-hidden="true" className="w-4 h-4 animate-spin motion-reduce:animate-none" />
);

export const AuthView: React.FC<AuthViewProps> = ({
  countryCodes,
  enabledMethods,
  onAuthenticated,
  isModal = false,
  onClose,
}) => {
  const uid = useId();
  const cardRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const [step, setStep] = useState<AuthStep>('IDENTIFY');
  const [selectedMethod, setSelectedMethod] = useState<string>(
    !enabledMethods.passkey && enabledMethods.emailOtp ? 'EMAIL_OTP' : 'PASSKEY'
  );
  const [identifier, setIdentifier] = useState<string>('');
  const [accessKey, setAccessKey] = useState<string>('');
  const [showAccessKey, setShowAccessKey] = useState<boolean>(false);
  const [revealSecret, setRevealSecret] = useState<boolean>(false);
  const [totpCode, setTotpCode] = useState<string>('');
  const [showPin, setShowPin] = useState<boolean>(false);

  // Sign-up completion
  const [displayName, setDisplayName] = useState<string>('');
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('+91');
  const [acceptedTerms, setAcceptedTerms] = useState<boolean>(false);
  const [isAdultConfirmed, setIsAdultConfirmed] = useState<boolean>(false);

  // Recovery
  const [recoveryCodeInput, setRecoveryCodeInput] = useState<string>('');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorRef, setErrorRef] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const currencyPreview = resolveCurrencyFromCountryCode(selectedCountryCode, countryCodes);
  const bothMethodsEnabled = enabledMethods.passkey && enabledMethods.emailOtp;

  // The 2-step PIN field only appears when it can matter.
  const recoveryLooksPrivileged = /^(ADM-REC-|MSTR-RST-)/i.test(recoveryCodeInput.trim());
  const pinVisibleInRecovery = showPin || recoveryLooksPrivileged;

  const showError = (message: string, ref?: string) => {
    setErrorMessage(message);
    setErrorRef(ref || null);
  };
  const clearError = () => {
    setErrorMessage(null);
    setErrorRef(null);
  };
  const goToStep = (next: AuthStep) => {
    clearError();
    setStep(next);
  };

  // Modal behaviour: Escape closes, focus stays inside, background does not scroll, focus returns on close.
  useEffect(() => {
    if (!isModal) return;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && onCloseRef.current) {
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab' || !cardRef.current) return;
      const focusables = Array.from(
        cardRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )
      ).filter((el) => el.offsetParent !== null);
      if (focusables.length === 0) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const active = document.activeElement as HTMLElement | null;
      if (e.shiftKey && (active === first || !cardRef.current.contains(active))) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && (active === last || !cardRef.current.contains(active))) {
        e.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = previousOverflow;
      previouslyFocused?.focus?.();
    };
  }, [isModal]);

  const handleIdentifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || !identifier.trim()) return;
    clearError();
    setLoading(true);

    try {
      const resp = await fetch('/api/auth/identify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: identifier.trim(),
          method: selectedMethod,
          passkeyCredential: accessKey.trim() || undefined,
          totpCode: totpCode.trim() || undefined,
        }),
      });
      const data = await resp.json();

      if (!resp.ok) {
        // Accounts that need a key and PIN: open those fields for the person.
        if (typeof data.refId === 'string' && data.refId.startsWith('ERR-ADM')) {
          setShowAccessKey(true);
        }
        showError(data.error || 'Could not verify your sign-in details.', data.refId || 'ERR-A100');
        return;
      }

      if (data.step === 'SIGNED_IN') {
        onAuthenticated({
          sessionToken: data.sessionToken,
          adminSessionToken: data.adminSessionToken,
          roleCategory: data.roleCategory,
          entitlementToken: data.entitlementToken,
          user: data.user,
          entitlement: data.entitlement,
          openAdminConsoleDirectly: Boolean(data.adminSessionToken),
        });
      } else if (data.step === 'COMPLETE_SIGNUP') {
        goToStep('COMPLETE_SIGNUP');
      }
    } catch {
      showError('Could not reach the sign-in service. Check your connection and try again.', 'ERR-N500');
    } finally {
      setLoading(false);
    }
  };

  const canCreateAccount = displayName.trim().length > 0 && acceptedTerms && isAdultConfirmed;

  const handleCompleteSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || !canCreateAccount) return;
    clearError();
    setLoading(true);

    try {
      const resp = await fetch('/api/auth/complete-signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pendingIdentifier: identifier,
          displayName,
          countryCode: selectedCountryCode,
          acceptedTerms,
          isAdultConfirmed,
          method: selectedMethod,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        showError(data.error || 'Could not create your account.', data.refId || 'ERR-C200');
        return;
      }

      onAuthenticated({
        sessionToken: data.sessionToken,
        entitlementToken: data.entitlementToken,
        user: data.user,
        entitlement: data.entitlement,
        oneTimeRecoveryKit: data.oneTimeRecoveryKit,
      });
    } catch {
      showError('Could not create your account right now. Please try again.', 'ERR-N501');
    } finally {
      setLoading(false);
    }
  };

  const handleRecoverySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    clearError();
    setLoading(true);

    try {
      const resp = await fetch('/api/auth/recover-with-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: identifier.trim(),
          recoveryCode: recoveryCodeInput.trim(),
          totpCode: totpCode.trim() || undefined,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        if (typeof data.refId === 'string' && data.refId.startsWith('ERR-ADM')) {
          setShowPin(true);
        }
        showError(data.error || 'That recovery code could not be verified.', data.refId || 'ERR-R100');
        return;
      }

      onAuthenticated({
        sessionToken: data.sessionToken,
        adminSessionToken: data.adminSessionToken,
        roleCategory: data.roleCategory,
        entitlementToken: data.entitlementToken,
        user: data.user,
        entitlement: data.entitlement,
        openAdminConsoleDirectly: Boolean(data.adminSessionToken),
      });
    } catch {
      showError('The recovery request could not be completed. Please try again.', 'ERR-N502');
    } finally {
      setLoading(false);
    }
  };

  const heading =
    step === 'IDENTIFY'
      ? 'Sign in or create an account'
      : step === 'COMPLETE_SIGNUP'
      ? 'Create your account'
      : 'Recover your account';

  const renderMethodButton = (id: string, label: string, icon: React.ReactNode) => (
    <button
      key={id}
      type="button"
      role="radio"
      aria-checked={selectedMethod === id}
      onClick={() => setSelectedMethod(id)}
      className={`min-h-[44px] px-3 py-2 rounded-xl text-sm font-medium border flex items-center justify-center gap-2 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32] ${
        selectedMethod === id
          ? 'bg-[#181615] text-[#FAF8F5] dark:bg-[#F5F2EB] dark:text-[#121110] border-[#181615] dark:border-[#F5F2EB]'
          : 'border-[#E7E2DA] dark:border-[#2E2B28] hover:border-[#B44C32]'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  const dialogCard = (
    <div
      ref={cardRef}
      role={isModal ? 'dialog' : undefined}
      aria-modal={isModal ? 'true' : undefined}
      aria-labelledby={`${uid}-title`}
      data-testid="general-auth-dialog"
      className="w-full max-w-3xl mx-auto rounded-2xl bg-white dark:bg-[#1C1A18] border border-[#E7E2DA] dark:border-[#2E2B28] shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-[5fr_6fr] relative"
    >
      {/* Left panel: what you are signing in to (desktop only) */}
      <aside className="hidden md:flex flex-col justify-between gap-10 p-8 bg-[#181615] text-[#F5F2EB]">
        <div className="flex items-center gap-2.5">
          <BrandMark className="w-9 h-9" />
          <span className="text-lg font-bold tracking-tight">Varnank Studios</span>
        </div>
        <ul className="space-y-5 text-sm leading-relaxed text-[#D6D0C6]">
          <li className="flex gap-3">
            <ShieldCheck aria-hidden="true" className="w-5 h-5 shrink-0 text-[#E06D53] mt-0.5" />
            <span>Your files are processed on your device and never uploaded.</span>
          </li>
          <li className="flex gap-3">
            <KeyRound aria-hidden="true" className="w-5 h-5 shrink-0 text-[#E06D53] mt-0.5" />
            <span>New here? You will set up your account in one more step.</span>
          </li>
          <li className="flex gap-3">
            <LifeBuoy aria-hidden="true" className="w-5 h-5 shrink-0 text-[#E06D53] mt-0.5" />
            <span>Your plan and saved settings follow you to any device.</span>
          </li>
        </ul>
      </aside>

      {/* Right panel: the form */}
      <div className="p-6 sm:p-8 space-y-5">
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            data-testid="close-auth-dialog-btn"
            className="absolute top-3 right-3 w-10 h-10 rounded-lg flex items-center justify-center text-[#57534E] dark:text-[#A8A29E] hover:text-[#181615] dark:hover:text-[#F5F2EB] hover:bg-[#FAF8F5] dark:hover:bg-[#262320] transition-colors focus-visible:outline-2 focus-visible:outline-[#B44C32]"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <div className="md:hidden flex items-center gap-2.5">
          <BrandMark className="w-7 h-7" />
          <span className="text-base font-bold tracking-tight">Varnank Studios</span>
        </div>

        <div className="pr-8">
          {step === 'COMPLETE_SIGNUP' && (
            <p className="text-xs text-[#57534E] dark:text-[#A8A29E] mb-1">Step 2 of 2</p>
          )}
          <h1
            id={`${uid}-title`}
            className="text-xl sm:text-2xl font-bold text-[#181615] dark:text-[#F5F2EB]"
          >
            {heading}
          </h1>
          <p className="text-sm text-[#57534E] dark:text-[#A8A29E] mt-1.5 leading-relaxed">
            {step === 'IDENTIFY' && 'Enter your email or account handle to continue.'}
            {step === 'COMPLETE_SIGNUP' && (
              <>
                No account found for{' '}
                <span className="font-semibold text-[#181615] dark:text-[#F5F2EB] break-words">
                  {identifier.trim()}
                </span>
                , so we will create one.{' '}
                <button type="button" onClick={() => goToStep('IDENTIFY')} className={LINK_BTN_CLASS}>
                  Change
                </button>
              </>
            )}
            {step === 'RECOVERY' && 'Use one of the single-use codes you saved when you signed up.'}
          </p>
        </div>

        <div aria-live="assertive">
          {errorMessage && (
            <div
              role="alert"
              data-testid="auth-error-alert"
              className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-300 dark:border-red-800 text-sm text-red-900 dark:text-red-200"
            >
              <p>{errorMessage}</p>
              {errorRef && (
                <p className="mt-1 text-xs font-mono text-red-800/80 dark:text-red-300/80">
                  Reference: {errorRef}
                </p>
              )}
            </div>
          )}
        </div>

        {step === 'IDENTIFY' && (
          <form onSubmit={handleIdentifySubmit} className="space-y-4" noValidate>
            {bothMethodsEnabled && (
              <div role="radiogroup" aria-label="Verification method" className="grid grid-cols-2 gap-2">
                {renderMethodButton('PASSKEY', 'Passkey', <KeyRound className="w-4 h-4" />)}
                {renderMethodButton('EMAIL_OTP', 'Email code', <Mail className="w-4 h-4" />)}
              </div>
            )}

            <div>
              <label htmlFor={`${uid}-identifier`} className="block text-sm font-medium mb-1.5">
                Email or account handle
              </label>
              <input
                id={`${uid}-identifier`}
                data-testid="auth-identifier-input"
                name="username"
                type="text"
                inputMode="email"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                autoFocus
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="name@example.com"
                className={FIELD_CLASS}
              />
            </div>

            <div>
              <button
                type="button"
                aria-expanded={showAccessKey}
                aria-controls={`${uid}-access-key-panel`}
                onClick={() => setShowAccessKey((v) => !v)}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-[#57534E] dark:text-[#A8A29E] hover:text-[#181615] dark:hover:text-[#F5F2EB] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B44C32] rounded-sm"
              >
                <ChevronDown
                  aria-hidden="true"
                  className={`w-4 h-4 transition-transform motion-reduce:transition-none ${showAccessKey ? 'rotate-180' : ''}`}
                />
                I have an access key
              </button>

              {showAccessKey && (
                <div id={`${uid}-access-key-panel`} className="mt-3 space-y-3">
                  <div>
                    <label htmlFor={`${uid}-access-key`} className="block text-sm font-medium mb-1.5">
                      Access key
                    </label>
                    <div className="relative">
                      <input
                        id={`${uid}-access-key`}
                        data-testid="auth-passkey-input"
                        name="access-key"
                        type={revealSecret ? 'text' : 'password'}
                        autoComplete="off"
                        autoCapitalize="none"
                        spellCheck={false}
                        value={accessKey}
                        onChange={(e) => setAccessKey(e.target.value)}
                        className={`${FIELD_CLASS} pr-11 font-mono text-xs`}
                      />
                      <button
                        type="button"
                        onClick={() => setRevealSecret((v) => !v)}
                        aria-label={revealSecret ? 'Hide access key' : 'Show access key'}
                        className="absolute right-1 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center text-[#57534E] dark:text-[#A8A29E] hover:text-[#181615] dark:hover:text-[#F5F2EB] rounded-lg focus-visible:outline-2 focus-visible:outline-[#B44C32]"
                      >
                        {revealSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label htmlFor={`${uid}-totp`} className="block text-sm font-medium mb-1.5">
                      6-digit authenticator PIN
                    </label>
                    <input
                      id={`${uid}-totp`}
                      data-testid="auth-totp-input"
                      name="totp"
                      type="password"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={6}
                      value={totpCode}
                      onChange={(e) => setTotpCode(e.target.value)}
                      className={`${FIELD_CLASS} font-mono tracking-widest`}
                    />
                  </div>
                </div>
              )}
            </div>

            <button
              type="submit"
              data-testid="unified-auth-submit-btn"
              disabled={loading || identifier.trim().length === 0}
              className={PRIMARY_BTN_CLASS}
            >
              {loading ? <Spinner /> : null}
              <span>{loading ? 'Checking…' : 'Continue'}</span>
              {!loading && <ArrowRight aria-hidden="true" className="w-4 h-4" />}
            </button>

            <p className="pt-1 text-sm text-[#57534E] dark:text-[#A8A29E]">
              Lost your device or passkey?{' '}
              <button type="button" onClick={() => goToStep('RECOVERY')} className={LINK_BTN_CLASS}>
                Use a recovery code
              </button>
            </p>
          </form>
        )}

        {step === 'COMPLETE_SIGNUP' && (
          <form onSubmit={handleCompleteSignupSubmit} className="space-y-4">
            <div>
              <label htmlFor={`${uid}-display-name`} className="block text-sm font-medium mb-1.5">
                Display name
              </label>
              <input
                id={`${uid}-display-name`}
                data-testid="signup-display-name-input"
                name="name"
                type="text"
                autoComplete="name"
                autoFocus
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. Aarav Sharma"
                className={FIELD_CLASS}
              />
              <p className="mt-1.5 text-xs text-[#57534E] dark:text-[#A8A29E]">
                Shown on your dashboard. You can change it later in Profile.
              </p>
            </div>

            <div>
              <label htmlFor={`${uid}-country`} className="block text-sm font-medium mb-1.5">
                Country code
              </label>
              <select
                id={`${uid}-country`}
                data-testid="signup-country-select"
                value={selectedCountryCode}
                onChange={(e) => setSelectedCountryCode(e.target.value)}
                className={FIELD_CLASS}
              >
                {countryCodes.map((c) => (
                  <option key={c.countryCode} value={c.countryCode}>
                    {c.countryName.includes(c.countryCode)
                      ? c.countryName
                      : `${c.countryCode} ${c.countryName}`}{' '}
                    · {c.currency}
                  </option>
                ))}
              </select>
              <div
                aria-live="polite"
                className="mt-2 p-3 rounded-xl bg-[#FAF8F5] dark:bg-[#262320] border border-[#E7E2DA] dark:border-[#2E2B28] text-sm"
              >
                <p className="font-semibold text-[#181615] dark:text-[#F5F2EB]">
                  Billing currency: {currencyPreview.currency}
                </p>
                <p className="text-xs text-[#57534E] dark:text-[#A8A29E] mt-0.5">
                  This is set by your country code and can’t be changed later.
                </p>
              </div>
            </div>

            <div className="space-y-3 pt-1">
              <label className="flex items-start gap-3 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  data-testid="signup-adult-checkbox"
                  checked={isAdultConfirmed}
                  onChange={(e) => setIsAdultConfirmed(e.target.checked)}
                  className="mt-0.5 w-5 h-5 shrink-0 accent-[#B44C32]"
                />
                <span>I’m 18 or older.</span>
              </label>
              <label className="flex items-start gap-3 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  data-testid="signup-terms-checkbox"
                  checked={acceptedTerms}
                  onChange={(e) => setAcceptedTerms(e.target.checked)}
                  className="mt-0.5 w-5 h-5 shrink-0 accent-[#B44C32]"
                />
                <span>
                  I agree to the Privacy Notice and Terms of Service. My files stay on my device.
                </span>
              </label>
            </div>

            <div className="flex gap-2.5 pt-1">
              <button type="button" onClick={() => goToStep('IDENTIFY')} className={SECONDARY_BTN_CLASS}>
                Back
              </button>
              <button
                type="submit"
                data-testid="signup-submit-btn"
                disabled={loading || !canCreateAccount}
                className={`${PRIMARY_BTN_CLASS} flex-1 w-auto`}
              >
                {loading ? <Spinner /> : null}
                <span>{loading ? 'Creating account…' : 'Create account'}</span>
              </button>
            </div>
          </form>
        )}

        {step === 'RECOVERY' && (
          <form onSubmit={handleRecoverySubmit} className="space-y-4" noValidate>
            <div>
              <label htmlFor={`${uid}-rec-identifier`} className="block text-sm font-medium mb-1.5">
                Email or account handle
              </label>
              <input
                id={`${uid}-rec-identifier`}
                data-testid="recovery-identifier-input"
                name="username"
                type="text"
                inputMode="email"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                autoFocus
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="name@example.com"
                className={FIELD_CLASS}
              />
            </div>

            <div>
              <label htmlFor={`${uid}-rec-code`} className="block text-sm font-medium mb-1.5">
                Recovery code
              </label>
              <input
                id={`${uid}-rec-code`}
                data-testid="recovery-code-input"
                name="recovery-code"
                type="text"
                autoComplete="off"
                autoCapitalize="characters"
                autoCorrect="off"
                spellCheck={false}
                required
                value={recoveryCodeInput}
                onChange={(e) => setRecoveryCodeInput(e.target.value)}
                className={`${FIELD_CLASS} font-mono text-xs`}
              />
              <p className="mt-1.5 text-xs text-[#57534E] dark:text-[#A8A29E]">
                Each code works once. Using it signs you in and uses that code up.
              </p>
            </div>

            {pinVisibleInRecovery ? (
              <div>
                <label htmlFor={`${uid}-rec-totp`} className="block text-sm font-medium mb-1.5">
                  6-digit authenticator PIN
                </label>
                <input
                  id={`${uid}-rec-totp`}
                  data-testid="recovery-totp-input"
                  name="totp"
                  type="password"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={6}
                  value={totpCode}
                  onChange={(e) => setTotpCode(e.target.value)}
                  className={`${FIELD_CLASS} font-mono tracking-widest`}
                />
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setShowPin(true)}
                className="text-sm font-medium text-[#57534E] dark:text-[#A8A29E] hover:text-[#181615] dark:hover:text-[#F5F2EB] underline underline-offset-2 focus-visible:outline-2 focus-visible:outline-[#B44C32] rounded-sm"
              >
                My account uses an authenticator PIN
              </button>
            )}

            <div className="flex gap-2.5 pt-1">
              <button type="button" onClick={() => goToStep('IDENTIFY')} className={SECONDARY_BTN_CLASS}>
                Back
              </button>
              <button
                type="submit"
                data-testid="recovery-submit-btn"
                disabled={loading || identifier.trim().length === 0 || recoveryCodeInput.trim().length === 0}
                className={`${PRIMARY_BTN_CLASS} flex-1 w-auto`}
              >
                {loading ? <Spinner /> : null}
                <span>{loading ? 'Checking…' : 'Recover account'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div
        data-testid="auth-modal-backdrop"
        onMouseDown={(e) => {
          if (e.target === e.currentTarget && onClose) onClose();
        }}
        className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 bg-black/55 backdrop-blur-xs overflow-y-auto"
      >
        {dialogCard}
      </div>
    );
  }

  return <div className="px-4 sm:px-6 py-10 pb-24">{dialogCard}</div>;
};

interface RecoveryKitModalProps {
  codes: string[];
  onClose: () => void;
}

export const RecoveryKitModal: React.FC<RecoveryKitModalProps> = ({ codes, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleCopyAll = async () => {
    try {
      await navigator.clipboard.writeText(codes.join('\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard blocked: the codes are still selectable on screen and downloadable
    }
  };

  const handleDownload = () => {
    const body = [
      'Varnank Studios recovery codes',
      'Each code works once. Keep this file somewhere safe and private.',
      '',
      ...codes,
      '',
    ].join('\n');
    const url = URL.createObjectURL(new Blob([body], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'varnank-recovery-codes.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="recovery-kit-title"
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="max-w-md w-full p-6 rounded-2xl bg-white dark:bg-[#1C1A18] border border-[#E7E2DA] dark:border-[#2E2B28] shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-[#15803D] dark:text-[#4ADE80]">
          <ShieldCheck aria-hidden="true" className="w-5 h-5" />
          <span className="text-sm font-semibold">Shown once. Save these now.</span>
        </div>

        <h2 id="recovery-kit-title" className="text-lg font-bold text-[#181615] dark:text-[#F5F2EB]">
          Your {codes.length} recovery codes
        </h2>
        <p className="text-sm text-[#57534E] dark:text-[#A8A29E] leading-relaxed">
          If you lose your device or passkey, any one of these codes signs you back in. Each works
          once. We keep only a one-way hash, so we can’t show them again.
        </p>

        <div className="grid grid-cols-2 gap-2 p-3.5 rounded-xl bg-[#FAF8F5] dark:bg-[#262320] border border-[#E7E2DA] dark:border-[#2E2B28] font-mono text-xs">
          {codes.map((c) => (
            <div key={c} className="py-1.5 px-2 rounded bg-white dark:bg-[#1C1A18] select-all">
              {c}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={handleCopyAll}
            className={`${SECONDARY_BTN_CLASS} flex items-center justify-center gap-1.5`}
          >
            {copied ? <Check className="w-4 h-4 text-[#15803D]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className={`${SECONDARY_BTN_CLASS} flex items-center justify-center gap-1.5`}
          >
            <Download className="w-4 h-4" />
            <span>Download</span>
          </button>
        </div>

        <label className="flex items-start gap-3 text-sm cursor-pointer">
          <input
            type="checkbox"
            checked={saved}
            onChange={(e) => setSaved(e.target.checked)}
            className="mt-0.5 w-5 h-5 shrink-0 accent-[#B44C32]"
          />
          <span>I’ve saved these codes somewhere safe.</span>
        </label>

        <button type="button" onClick={onClose} disabled={!saved} className={PRIMARY_BTN_CLASS}>
          Continue
        </button>
      </div>
    </div>
  );
};
